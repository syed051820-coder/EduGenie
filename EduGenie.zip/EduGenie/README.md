# EduGenie

## Run it in VS Code

1. Open this folder in VS Code.
2. Open a terminal (`` Ctrl+` ``) and create a virtual environment:
   ```
   python -m venv .venv
   .venv\Scripts\activate      # Windows
   source .venv/bin/activate   # macOS/Linux
   ```
3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
4. Check `.env` has a valid `GEMINI_API_KEY` (get one at https://aistudio.google.com/app/apikey).
5. Run the app:
   ```
   python main.py
   ```
   or
   ```
   uvicorn main:app --reload
   ```
6. Open http://127.0.0.1:8000 in your browser.

## What was fixed from the original

- `static/` and `templates/` folders didn't exist, so `StaticFiles(directory="static")`
  crashed the app immediately on startup. Both folders are now included, and `main.py`
  also creates them automatically if they're ever missing.
- `.env` was never loaded — `python-dotenv` was in `requirements.txt` but `load_dotenv()`
  was never called, so `GEMINI_API_KEY` was invisible to the app.
- The env var was named `GEMINI_API_Key` (mixed case). Environment variable names are
  case-sensitive on Linux/macOS, so this silently failed to match `GEMINI_API_KEY`.
  Renamed to `GEMINI_API_KEY`.
- `GEMINI_MODEL=gemini-3.8-flash` isn't a real Gemini model name — changed to
  `gemini-3.5-flash`, a current valid model.
- There was no actual AI functionality wired up — only `/` and `/health` existed.
  Added a working `/api/ask` endpoint (used by the included front-end) that calls
  Gemini, with a safe demo-mode fallback if no key is configured.
- Added `config.py` using `pydantic-settings` to load and validate env vars cleanly.
- Added a minimal working front end (`templates/index.html`, `static/style.css`,
  `static/script.js`) since none existed.

## Security note

Your uploaded `.env` contained a real Gemini API key in plain text. Since you shared
it in this chat, treat that key as potentially exposed — rotate it in Google AI Studio
and put the new one in `.env`. A `.gitignore` is included so `.env` won't get committed
to git by accident going forward.
